// src/App.js
import React from "react";
import { ThemeProvider } from "./ThemeContext";
import { ThemeContext } from "./ThemeContext";
import Portfolio from "./components/Portfolio";
import ThemeToggle from "./components/ThemeToggle";
import Contact from "./components/Contact";

const App = () => {
  const styles = {
    app: {
      fontFamily: "Arial, sans-serif",
      padding: "20px",
      maxWidth: "600px",
      margin: "0 auto",
    },
  };

  return (
    <ThemeProvider>
      <div style={styles.app}>
        <Portfolio />
        <ThemeToggle />
        <Contact />
      </div>
    </ThemeProvider>
  );
};

export default App;
