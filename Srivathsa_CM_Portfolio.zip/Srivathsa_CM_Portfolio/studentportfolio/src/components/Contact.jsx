// src/components/Contact.js
import React, { useRef, useContext } from "react";
import { ThemeContext } from "../ThemeContext";

const Contact = () => {
  const inputRef = useRef(null);
  const { theme } = useContext(ThemeContext);

  const handleFocus = () => {
    inputRef.current.focus();
    alert("Input focused!");
  };

  const styles = {
    container: {
      textAlign: "center",
      marginTop: "30px",
      padding: "20px",
      backgroundColor: theme === "light" ? "#f8ebebff" : "#333",
      borderRadius: "8px",
    },
    input: {
      padding: "10px",
      width: "250px",
      marginRight: "10px",
      border: "1px solid #dbc8c8ff",
      borderRadius: "4px",
      backgroundColor: theme === "light" ? "#fff" : "#555",
      color: theme === "light" ? "#000" : "#e4d1d1ff",
    },
    button: {
      padding: "10px 15px",
      border: "none",
      borderRadius: "4px",
      backgroundColor: theme === "light" ? "#333" : "#ddd",
      color: theme === "light" ? "#fff" : "#000",
      cursor: "pointer",
    },
  };

  return (
    <div style={styles.container}>
      <h3>Contact Me</h3>
      <input ref={inputRef} type="text" placeholder="Your message..." style={styles.input} />
      <button onClick={handleFocus} style={styles.button}>
        Focus on Input
      </button>
    </div>
  );
};

export default Contact;
