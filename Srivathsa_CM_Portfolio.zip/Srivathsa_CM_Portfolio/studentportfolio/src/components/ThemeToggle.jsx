
import React, { useContext } from "react";
import { ThemeContext } from "../ThemeContext";

const ThemeToggle = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);

  const styles = {
    button: {
      margin: "20px auto",
      display: "block",
      padding: "10px 20px",
      fontSize: "1em",
      backgroundColor: theme === "light" ? "#333" : "#ddd",
      color: theme === "light" ? "#fff" : "#000",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
    },
  };

  return (
    <button style={styles.button} onClick={toggleTheme}>
      Switch to {theme === "light" ? "Dark" : "Light"} Theme
    </button>
  );
};

export default ThemeToggle;
