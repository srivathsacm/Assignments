// src/components/Portfolio.js
import React, { useContext } from "react";
import { ThemeContext } from "../ThemeContext";

const Portfolio = () => {
  const { theme } = useContext(ThemeContext);

  const isLight = theme === "light";

  const styles = {
    container: {
      backgroundColor: isLight ? "#f9f9f9" : "#222",
      color: isLight ? "#222" : "#f9f9f9",
      minHeight: "60vh",
      padding: "30px",
      textAlign: "center",
      borderRadius: "8px",
    },
    image: {
      borderRadius: "50%",
      width: "120px",
      height: "120px",
      objectFit: "cover",
      marginBottom: "15px",
    },
    name: {
      fontSize: "2em",
      fontWeight: "bold",
    },
    role: {
      fontSize: "1.2em",
      color: isLight ? "#444" : "#ddd",
    },
    about: {
      marginTop: "10px",
      fontSize: "1em",
      lineHeight: "1.6",
    },
  };

  return (
    <div style={styles.container}>
      <img
        src="profile.jpg"
        alt="Profile"
        style={styles.image}
      />
      <div style={styles.name}>SRIVATHSA CM</div>
      <div style={styles.role}>Frontend Developer</div>
      <p style={styles.about}>
        Hi! I’m Srivathsa, a passionate frontend developer skilled in React and
        modern JavaScript. I enjoy crafting clean, responsive, and accessible
        user interfaces.
      </p>
      <p> Current Theme: <strong>{theme.toUpperCase()}</strong></p>
    </div>
  );
};

export default Portfolio;
