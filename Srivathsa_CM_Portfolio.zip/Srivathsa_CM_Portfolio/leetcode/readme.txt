plusOne - Java Solution

This Java function adds 1 to a number represented as an array of digits.

Function:
public int[] plusOne(int[] digits);

Approach:

Traverse the digits from right to left.

Add 1 to the current digit; handle carry-over if needed.

If all digits are 9, create a new array with one more digit, setting the first digit to 1.
