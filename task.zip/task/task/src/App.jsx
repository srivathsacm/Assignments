import React from 'react';
import Task from './Task.jsx';

function App() {
  return (
   <Task/>
  )
}

export default App
