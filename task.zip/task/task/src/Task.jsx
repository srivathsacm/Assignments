import React from 'react';
const cardStyle={
  backgroundColor:'#ffffff',
  boShadow:'0 4px 15px rgba(0, 0, 0, 0.1)',
  padding:'30px',
  textAlign:'center',
  width:'250px',
  transition:'transform 0.3s ease',
};
const imgStyle={
  width:'120px',
  height:'120px',
  borderRadius:'50%',
  marginBottom:'15px',
};
const textStyle ={
  color:'#333',
  fontFamily:'Poppins, sans-serif',
  lineHeight:'1.5',
  fontSize:'16px',
};

function Task1(){
  return (
      <div style={cardStyle} className="profile-card">
        <img src="https://media.licdn.com/dms/image/v2/D5635AQFoetVRgTFWrw/profile-framedphoto-shrink_400_400/B56ZohJsM5I4Ac-/0/1761492780042?e=1763046000&v=beta&t=aWZ55Uz3puqhwuMUBrXkiDskp8Zx-wVIHM7u0f6_JAM" alt="Profile" style={imgStyle}
        />
        <p style={textStyle}><strong>SRIVATHSA</strong><br/>B.E Final Year Student</p>
      </div>
  );
}

export default Task1;