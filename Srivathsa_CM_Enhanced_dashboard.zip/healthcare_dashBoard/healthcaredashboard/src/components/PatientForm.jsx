
import React, { useEffect, useState } from 'react';

const fieldStyle = { display: 'block', width: '100%', padding: 8, marginBottom: 8, borderRadius: 6, border: '1px solid #ccc' };

const PatientForm = ({ onSubmit, patientToEdit }) => {
  const [form, setForm] = useState({ id: null, name: '', age: '', condition: '', lastVisit: '' });

  useEffect(() => {
    if (patientToEdit) {
      setForm({ ...patientToEdit });
    }
  }, [patientToEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((s) => ({ ...s, [name]: value }));
  };

  const submit = (e) => {
    e.preventDefault();
   
    if (!form.name.trim()) {
      alert('Please enter name');
      return;
    }
    onSubmit({ ...form });
    setForm({ id: null, name: '', age: '', condition: '', lastVisit: '' });
  };

  return (
    <>
      <form onSubmit={submit} style={{ marginBottom: 16, background: '#f7fbff', padding: 12, borderRadius: 8 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 120px', gap: 8 }}>
          <input name="name" value={form.name} onChange={handleChange} placeholder="Name" style={fieldStyle} />
          <input name="age" value={form.age} onChange={handleChange} placeholder="Age" style={fieldStyle} />
          <input name="condition" value={form.condition} onChange={handleChange} placeholder="Condition" style={fieldStyle} />
          <input name="lastVisit" value={form.lastVisit} onChange={handleChange} placeholder="Last Visit (YYYY-MM-DD)" style={fieldStyle} />
        </div>
        <div style={{ marginTop: 8, textAlign: 'right' }}>
          <button type="submit" style={{ padding: '8px 14px', borderRadius: 6, background: '#1298e1ff', color: '#fff', border: 'none' }}>
            {form.id ? 'Update' : 'Add'} Patient
          </button>
        </div>
      </form>
    </>
  );
};

export default React.memo(PatientForm);
