
import React from 'react';

function PatientCardInner({ patient, onEdit, onDelete }) {
  if (!patient) return null;

  return (
    <>
      <div style={{ background: '#fff', padding: 12, borderRadius: 8, boxShadow: '0 1px 4px rgba(0,0,0,0.08)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ margin: 0 }}>{patient.name}</h3>
            <div style={{ fontSize: 13, color: '#666' }}>Age: {patient.age}</div>
          </div>
          <div style={{ fontSize: 12, color: '#999' }}>Last visit: {patient.lastVisit}</div>
        </div>

        <p style={{ marginTop: 12, marginBottom: 8 }}>Condition: {patient.condition}</p>

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <button onClick={onEdit} style={{ padding: '6px 8px', borderRadius: 6 }}>Edit</button>
          <button onClick={onDelete} style={{ padding: '6px 8px', borderRadius: 6, background: '#fee2e2', border: '1px solid #fca5a5' }}>Delete</button>
        </div>
      </div>
    </>
  );
}


const areEqual = (prevProps, nextProps) => {
  const a = prevProps.patient;
  const b = nextProps.patient;
  const samePatient =
    a?.id === b?.id &&
    a?.name === b?.name &&
    a?.age === b?.age &&
    a?.condition === b?.condition &&
    a?.lastVisit === b?.lastVisit;

  const sameHandlers = prevProps.onEdit === nextProps.onEdit && prevProps.onDelete === nextProps.onDelete;
  return samePatient && sameHandlers;
};

export default React.memo(PatientCardInner, areEqual);
