
import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';

const modalRootId = 'modal-root';

function ensureModalRoot() {
  let root = document.getElementById(modalRootId);
  if (!root) {
    root = document.createElement('div');
    root.id = modalRootId;
    document.body.appendChild(root);
  }
  return root;
}

export default function Modal({ children, onClose }) {
  const el = document.createElement('div');

  useEffect(() => {
    const modalRoot = ensureModalRoot();
    modalRoot.appendChild(el);

    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.();
    };
    document.addEventListener('keydown', onKey);

    return () => {
      document.removeEventListener('keydown', onKey);
      modalRoot.removeChild(el);
     
      const mr = document.getElementById(modalRootId);
      if (mr && mr.childElementCount === 0) {
        mr.parentElement?.removeChild(mr);
      }
    };
    
  }, [el, onClose]);

  const backdrop = (
    <>
      <div
        style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.4)',
          zIndex: 1000,
        }}
        onMouseDown={onClose}
      />
      <div
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          zIndex: 1001,
          minWidth: 320,
          maxWidth: '90%',
        }}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </>
  );

  return createPortal(backdrop, el);
}
