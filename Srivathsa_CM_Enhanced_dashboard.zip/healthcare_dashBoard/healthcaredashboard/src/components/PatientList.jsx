
import React, { Fragment } from 'react';
import PatientCard from './PatientCard';


const PatientList = ({ patients = [], onEdit, onDelete }) => {
  if (!patients || patients.length === 0) {
    return <p>No patients found. Add one above.</p>;
  }

  return (
    <section>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 12 }}>
        {patients.map((p) => (
          <Fragment key={p.id}>
            <PatientCard patient={p} onEdit={() => onEdit(p)} onDelete={() => onDelete(p.id)} />
          </Fragment>
        ))}
      </div>
    </section>
  );
};

export default React.memo(PatientList);
