
import React, { useReducer, useCallback, useState, Fragment } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { patientReducer, initialPatients } from './reducer/patientReducer';
import { useLocalStorage } from './hooks/useLocalStorage';
import PatientForm from './components/PatientForm';
import PatientList from './components/PatientList';
import Modal from './components/Modal';
import ErrorBoundary from './components/ErrorBoundary';

const containerStyle = {
  maxWidth: '900px',
  margin: '0 auto',
  padding: '20px',
  fontFamily: 'Arial, sans-serif',
  color: '#1298e1ff',
};

const headerStyle = {
  textAlign: 'center',
  marginBottom: '20px',
};

export const App = () => {
 
  const [patients, dispatch] = useReducer(patientReducer, initialPatients);

  
  useLocalStorage('patients', patients, dispatch);

  const [patientToEdit, setPatientToEdit] = useState(null);
  const [modalState, setModalState] = useState({ open: false, payloadId: null });

  const handleAdd = useCallback((patient) => {
    if (patient.id) {
      dispatch({ type: 'UPDATE_PATIENT', payload: patient });
    } else {
      dispatch({ type: 'ADD_PATIENT', payload: { ...patient, id: uuidv4() } });
    }
    setPatientToEdit(null);
  }, []);

  const handleEdit = useCallback((patient) => {
    setPatientToEdit(patient);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

 
  const handleDeleteRequest = useCallback((id) => {
    setModalState({ open: true, payloadId: id });
  }, []);

  const confirmDelete = useCallback(() => {
    dispatch({ type: 'DELETE_PATIENT', payload: modalState.payloadId });
    setModalState({ open: false, payloadId: null });
  }, [modalState]);

  const cancelDelete = useCallback(() => {
    setModalState({ open: false, payloadId: null });
  }, []);

  return (
    <Fragment>
      <div style={containerStyle}>
        <h1 style={headerStyle}>Healthcare Dashboard — Enhanced</h1>

        <ErrorBoundary>
          <PatientForm onSubmit={handleAdd} patientToEdit={patientToEdit} />
          <PatientList patients={patients} onEdit={handleEdit} onDelete={handleDeleteRequest} />
        </ErrorBoundary>
      </div>

      {modalState.open && (
        <Modal onClose={cancelDelete}>
          <>
            <h3 style={{ marginTop: 0 }}>Confirm Delete</h3>
            <p>Are you sure you want to delete this patient record?</p>
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: 12 }}>
              <button onClick={cancelDelete} style={{ padding: '6px 10px', borderRadius: 6 }}>Cancel</button>
              <button onClick={confirmDelete} style={{ padding: '6px 10px', borderRadius: 6, background: '#e53e3e', color: '#fff', border: 'none' }}>Delete</button>
            </div>
          </>
        </Modal>
      )}
    </Fragment>
  );
};

export default App;
