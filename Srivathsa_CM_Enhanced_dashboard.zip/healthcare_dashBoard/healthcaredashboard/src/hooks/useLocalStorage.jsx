
import { useEffect } from 'react';

export function useLocalStorage(key, value, dispatch) {
  
  useEffect(() => {
    try {
      const s = JSON.stringify(value);
      localStorage.setItem(key, s);
    } catch (e) {
      
      console.error('useLocalStorage: write error', e);
    }
  }, [key, value]);

 
  useEffect(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
       
        dispatch({ type: 'SET_PATIENTS', payload: parsed });
      }
    } catch (e) {
      console.error('useLocalStorage: read error', e);
    }
   }, [key]);
}
