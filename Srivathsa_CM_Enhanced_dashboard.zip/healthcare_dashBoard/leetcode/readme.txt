Isomorphic Strings:Two strings s and t are isomorphic if the characters in s can be replaced to get t.

Each character in s must map to one unique character in t, and the mapping must be consistent throughout the string.

 Example
Input	Output	Explanation
s = "egg", t = "add"	true	e → a, g → d
s = "foo", t = "bar"	false	o maps to two different characters
s = "paper", t = "title"	true	consistent one-to-one mapping
Approach

To check if two strings are isomorphic:

Track character mapping from s → t

Track reverse mapping from t → s

If a conflicting mapping occurs, return false