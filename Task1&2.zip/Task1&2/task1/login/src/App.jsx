import React from "react";
import { LoginPage } from "./login";

export const App = () => {
  return (
    <>
      <LoginPage />
    </>
  );
};
export default App