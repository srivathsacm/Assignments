import React, { useState } from "react";

export const LoginPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showImages, setShowImages] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (username.trim() && password.trim()) {
      setShowImages(true); 
      setUsername("");
      setPassword("");
    } else {
      alert("Please enter both username and password.");
    }
  };

  const containerStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100vh",
    backgroundColor: "#a9c722ff",
    fontFamily: "Arial, sans-serif",
  };

  const formStyle = {
    background: "pink",
    padding: "30px",
    borderRadius: "12px",
    boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
    width: "300px",
    textAlign: "center",
  };

  const inputStyle = {
    backgroundColor: "black",
    color: "white",
    width: "100%",
    padding: "10px",
    margin: "10px 0",
    borderRadius: "6px",
    border: "1px solid #1f19c9ff",
  };

  const buttonStyle = {
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    padding: "10px 20px",
    borderRadius: "6px",
    cursor: "pointer",
  };

  const galleryStyle = {
    marginTop: "30px",
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
    gap: "15px",
    width: "80%",
  };

  const imgStyle = {
    width: "100%",
    height: "150px",
    objectFit: "cover",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
  };

  const images = [
    "https://picsum.photos/id/1015/300/200",
    "https://picsum.photos/id/1025/300/200",
    "https://picsum.photos/id/1043/300/200",
    "https://picsum.photos/id/1052/300/200",
    "https://picsum.photos/id/1069/300/200",
    "https://picsum.photos/id/1074/300/200",
  ];

  return (
    <div style={containerStyle}>
      <form onSubmit={handleSubmit} style={formStyle}>
        <h2>Login</h2>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          style={inputStyle}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={inputStyle}
        />
        <button type="submit" style={buttonStyle}>
          Login
        </button>
      </form>

      
      {showImages && (
        <div style={galleryStyle}>
          {images.map((img, index) => (
            <img key={index} src={img} alt={`Gallery ${index}`} style={imgStyle} />
          ))}
        </div>
      )}
    </div>
  );
};
