import React, { useState } from "react";
import FormContainer from "../components/FormContainer";
import Button from "../components/Button";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Login with Email: ${email}, Password: ${password}`);
  };

  return (
    <FormContainer title="Login">
      <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
        <input
          type="email"
          placeholder="Email"
          className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <Button text="Login" type="submit" />
      </form>
      <p className="text-center text-sm text-gray-500 mt-3 cursor-pointer hover:underline">
        Forgot password?
      </p>
    </FormContainer>
  );
};

export default LoginPage;
