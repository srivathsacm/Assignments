import React, { useState } from "react";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";

const App = () => {
  const [activeTab, setActiveTab] = useState("login");

  return (
    <div className="bg-gray-50 min-h-screen flex flex-col items-center justify-center">
      {/* Tab Navigation */}
      <div className="flex space-x-10 mb-6">
        <button
          onClick={() => setActiveTab("login")}
          className={`text-lg font-semibold border-b-2 ${
            activeTab === "login"
              ? "border-blue-600 text-blue-600"
              : "border-transparent text-gray-500"
          }`}
        >
          Login
        </button>
        <button
          onClick={() => setActiveTab("register")}
          className={`text-lg font-semibold border-b-2 ${
            activeTab === "register"
              ? "border-blue-600 text-blue-600"
              : "border-transparent text-gray-500"
          }`}
        >
          Register
        </button>
      </div>

      {/* Forms Side by Side */}
      <div className="flex gap-10 flex-wrap justify-center">
        {activeTab === "login" ? <LoginPage /> : <RegisterPage />}
      </div>
    </div>
  );
};

export default App;
