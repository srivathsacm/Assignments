import React from "react";

const Button = ({ text, onClick, type = "button", className = "", children }) => {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md font-semibold transition duration-200 ${className}`}
    >
      {children || text}
    </button>
  );
};

export default Button;
