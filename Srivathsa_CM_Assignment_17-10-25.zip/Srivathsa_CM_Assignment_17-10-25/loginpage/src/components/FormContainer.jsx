import React from "react";

const FormContainer = ({ title, children }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md w-80">
      <h2 className="text-xl font-bold text-center mb-5">{title}</h2>
      {children}
    </div>
  );
};

export default FormContainer;
