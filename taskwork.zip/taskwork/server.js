const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use("/uploads", express.static("uploads"));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => {
    const id = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, id + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

app.post("/upload", upload.array("images"), (req, res) => {
  const files = req.files.map(f => ({
    filename: f.filename,
    url: "http://localhost:5000/uploads/" + f.filename
  }));
  res.json({ success: true, files });
});

app.listen(5000, () => console.log("Server running → http://localhost:5000"));
