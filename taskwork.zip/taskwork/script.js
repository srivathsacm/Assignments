const uploadBox = document.getElementById("uploadBox");
const browseBtn = document.getElementById("browseBtn");
const fileInput = document.getElementById("fileInput");
const preview = document.getElementById("preview");

let images = [];

// Browse button
browseBtn.addEventListener("click", () => fileInput.click());

// On file change
fileInput.addEventListener("change", (e) => {
    handleFiles([...e.target.files]);
});

// Drag over
uploadBox.addEventListener("dragover", (e) => {
    e.preventDefault();
    uploadBox.classList.add("active");
});

// Drag leave
uploadBox.addEventListener("dragleave", () => {
    uploadBox.classList.remove("active");
});

// Drop
uploadBox.addEventListener("drop", (e) => {
    e.preventDefault();
    uploadBox.classList.remove("active");

    const droppedFiles = [...e.dataTransfer.files];
    handleFiles(droppedFiles);
});

// Handle multiple images
function handleFiles(files) {
    files.forEach(file => {
        if (file.type.startsWith("image/")) {
            const imgURL = URL.createObjectURL(file);
            images.push(imgURL);
        }
    });

    renderImages();
}

// Render all images
function renderImages() {
    preview.innerHTML = "";

    images.forEach((url, index) => {
        preview.innerHTML += `
            <div class="preview-item">
                <img src="${url}">
                <button class="remove-btn" onclick="removeImage(${index})">X</button>
            </div>
        `;
    });
}

// Remove specific image
function removeImage(index) {
    images.splice(index, 1);
    renderImages();
}
